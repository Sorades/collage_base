package com.example.collage_basecode.drawing;

import android.graphics.Canvas;
import android.graphics.NinePatch;
import android.graphics.RectF;

public class NinePartImage extends BaseVisualElement {

    private NinePatch patches;

    public NinePartImage(float x, float y, float w, float h, NinePatch patches){
        super(x,y,w,h);
        this.patches = patches;
    }

    @Override
    public void draw(Canvas onCanvas) {
        super.draw(onCanvas);
        RectF rect = new RectF(x,y,x+w,y+h);
        patches.draw(onCanvas,rect);
        drawChilds(onCanvas);

    }


}
