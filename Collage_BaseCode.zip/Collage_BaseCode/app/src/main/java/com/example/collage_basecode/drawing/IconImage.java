package com.example.collage_basecode.drawing;

import android.graphics.Bitmap;
import android.graphics.Canvas;

public class IconImage extends com.example.collage_basecode.drawing.BaseVisualElement {

    Bitmap image;

    public IconImage(float x, float y, Bitmap image){
        this.x = x;
        this.y = y;
        this.w = image.getWidth();
        this.h = image.getHeight();
        this.image = image;
    }

    @Override
    public void draw(Canvas onCanvas) {
        super.draw(onCanvas);
        onCanvas.drawBitmap(image,x,y,paint);
        drawChilds(onCanvas);

    }

    public IconImage() {
        super();

    }


}
