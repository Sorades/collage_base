package com.example.collage_basecode.drawing;

import android.graphics.Canvas;
import android.graphics.Paint;

public class SolidBackDrop extends BaseVisualElement {

    private int color;

    public SolidBackDrop() {
        super();
    }

    public SolidBackDrop(float x, float y, float w, float h, int color){
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.color = color;
        paint.setColor(color);
    }

    @Override
    public void draw(Canvas onCanvas) {
        super.draw(onCanvas);
        paint.setStyle(Paint.Style.FILL_AND_STROKE);
        onCanvas.drawRect(x,y,x+w,y+h,paint);
        drawChilds(onCanvas);
    }



}
