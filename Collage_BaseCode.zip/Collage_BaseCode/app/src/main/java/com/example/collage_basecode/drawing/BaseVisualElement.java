package com.example.collage_basecode.drawing;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.RectF;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

//接口-抽象类-基础类-具体类四层结构
//大多数公用功能都在此类实现
public class BaseVisualElement extends PrebaseVisualElement {

    float x,y,w,h;
    //使用接口！用接口作为父对象的类型
    com.example.collage_basecode.drawing.VisualElement parent = null;
    List<com.example.collage_basecode.drawing.VisualElement> childs = new ArrayList<com.example.collage_basecode.drawing.VisualElement>();
    Paint paint = new Paint();

    public BaseVisualElement() {
        super();
    }

    public BaseVisualElement(float xLoc, float yLoc) {
        super(xLoc, yLoc);
        x = xLoc;
        y = yLoc;
    }

    public BaseVisualElement(float xLoc, float yLoc, float width, float height) {
        super(xLoc, yLoc, width, height);
        x = xLoc;
        y = yLoc;
        w = width;
        h = height;
    }

    @Override
    public void setPosition(PointF pos) {
        try {
            x = pos.x;
            y = pos.y;
        } catch (Exception e){
            Log.d("error","setPositionError");
        }
    }

    @Override
    public void setPosition(float x, float y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public void setX(float x) {
        this.x = x;
    }

    @Override
    public void setY(float y) {
        this.y = y;
    }

    @Override
    public PointF getPosition() {
        return new PointF(x,y);
    }

    @Override
    public float getX() {
        return x;
    }

    @Override
    public float getY() {
        return y;
    }

    @Override
    public boolean sizeIsIntrinsic() {
        return super.sizeIsIntrinsic();
    }

    @Override
    public void setSize(PointF size) {
       try{
           w = size.x;
           h = size.y;
       } catch (Exception e){
           Log.d("error","setSizeError");
       }

    }

    @Override
    public void setSize(float w, float h) {
        super.setSize(w, h);
        this.w = w;
        this.h = h;
    }

    @Override
    public void setW(float w) {
        this.w = w;
    }

    @Override
    public void setH(float h) {
        this.h = h;
    }

    @Override
    public PointF getSize() {
        return new PointF(w,h);
    }

    @Override
    public float getW() {
        return w;
    }

    @Override
    public float getH() {
        return h;
    }

    @Override
    public com.example.collage_basecode.drawing.VisualElement getParent() {
        return parent;
    }

    @Override
    public void setParent(com.example.collage_basecode.drawing.VisualElement newParent) {
        parent = newParent;
    }

    @Override
    public int getNumChildren() {
        return childs.size();
    }

    @Override
    public com.example.collage_basecode.drawing.VisualElement getChildAt(int index) {
        try {
            return childs.get(index);
        } catch (Exception e){
            return  null;
        }
    }

    @Override
    public int findChild(com.example.collage_basecode.drawing.VisualElement child) {
        return childs.indexOf(child);
    }

    @Override
    public void addChild(com.example.collage_basecode.drawing.VisualElement child) {
        if (child == null) return;
        com.example.collage_basecode.drawing.VisualElement oldParent = child.getParent();
        if (oldParent != null){
            oldParent.removeChild(child);
        }
        child.setParent(this);
        childs.add(child);
    }

    @Override
    public void removeChildAt(int index) {
        com.example.collage_basecode.drawing.VisualElement child = childs.get(index);
        child.setParent(null);
        childs.remove(index);

    }

    @Override
    public void removeChild(com.example.collage_basecode.drawing.VisualElement child) {
        child.setParent(null);
        childs.remove(child);
    }

    @Override
    public void moveChildFirst(com.example.collage_basecode.drawing.VisualElement child) {
        childs.remove(child);
        childs.add(0,child);
    }

    @Override
    public void moveChildLast(com.example.collage_basecode.drawing.VisualElement child) {
        childs.remove(child);
        childs.add(child);
    }

    @Override
    public void moveChildEarlier(com.example.collage_basecode.drawing.VisualElement child) {
        int index = childs.indexOf(child);
        if (index>0) {
            childs.set(index,childs.get(index-1));
            childs.set(index-1,child);
        }
    }

    @Override
    public void moveChildLater(com.example.collage_basecode.drawing.VisualElement child) {
        int index = childs.indexOf(child);
        if (index<childs.size()-1) {
            childs.set(index,childs.get(index+1));
            childs.set(index+1,child);
        }

    }

    @Override
    public void doLayout() {

    }

    //在这里执行绘制自身前所有对象都要执行的动作，即根据父视图修改大小
    @Override
    public void draw(Canvas onCanvas) {
        if (getParent() == null){
            return;
        }

        if ( getParent().getW()-x < w) {
            w = getParent().getW()-x;
            if (w < 0) w = 0;
        }
        if (getParent().getH() - y < h){
            h = getParent().getH() - y;
            if (h < 0) h = 0;
        }

    }

    //在这里执行绘制自身后所有对象都要执行的动作，即绘制所有子视图
    protected void drawChilds(Canvas onCanvas){
        onCanvas.save();
        onCanvas.translate(x,y);
        //通过将左起始位置和上起始位置设为-1而非0来以及右侧位置和下方位置+1保证边界线可以画出
        onCanvas.clipRect(new RectF(0-1f,0-1f,w+1,h+1));
        for (com.example.collage_basecode.drawing.VisualElement child:
                childs) {
            child.draw(onCanvas);
        }
        onCanvas.translate(-x,-y);
        onCanvas.restore();
    }
}
