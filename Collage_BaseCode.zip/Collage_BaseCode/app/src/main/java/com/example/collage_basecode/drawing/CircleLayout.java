package com.example.collage_basecode.drawing;

import android.graphics.Canvas;

public class CircleLayout extends BaseVisualElement {

    float layoutCenterX;
    float layoutCenterY;
    float layoutRadius;

    public CircleLayout(float x,float y,float w,float h,float layoutCenterX,float layoutCenterY,float layoutRadius){
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.layoutCenterX = layoutCenterX;
        this.layoutCenterY = layoutCenterY;
        this.layoutRadius = layoutRadius;
    }

    @Override
    public void doLayout() {
        super.doLayout();
        VisualElement child;
        float arc = (float)(Math.PI * 2/childs.size());

        for (int i = 0;i<childs.size();i++){
            child = childs.get(i);
            float a = (float) (layoutCenterX+layoutRadius*Math.cos(arc*i)-child.getW()/2);
            float b = (float) (layoutCenterY+layoutRadius*Math.sin(arc*i)-child.getH()/2);
            child.setX(a);
            child.setY(b);
            //child.doLayout();
        }
    }

    @Override
    public void draw(Canvas onCanvas) {
        super.draw(onCanvas);
        doLayout();
        drawChilds(onCanvas);
    }
}
