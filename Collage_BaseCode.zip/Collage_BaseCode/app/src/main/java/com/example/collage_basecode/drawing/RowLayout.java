package com.example.collage_basecode.drawing;

import android.graphics.Canvas;

public class RowLayout extends BaseVisualElement {

    public RowLayout(float xLoc, float yLoc, float width, float height) {
        super(xLoc, yLoc, width, height);
    }


    @Override
    public void doLayout() {
        int l = 0;
        for (VisualElement child:childs
             ) {
            child.setX(l);
            child.setY((h-child.getH())/2);
            l += child.getW();
            //child.doLayout();
        }
    }

    @Override
    public void draw(Canvas onCanvas) {
        super.draw(onCanvas);
        doLayout();
        drawChilds(onCanvas);
    }
}
