package com.example.collage_basecode.drawing;

import android.graphics.Canvas;

public class ColumnLayout extends BaseVisualElement {

    public ColumnLayout(float xLoc, float yLoc, float width, float height) {
        super(xLoc, yLoc, width, height);
    }

    @Override
    public void doLayout() {
        int u = 0;
        for (com.example.collage_basecode.drawing.VisualElement child:childs
             ) {
            child.setY(u);
            child.setX((w-child.getW())/2);
            u += child.getH();
            //child.doLayout();
        }
    }

    @Override
    public void draw(Canvas onCanvas) {
        super.draw(onCanvas);
        doLayout();
        drawChilds(onCanvas);
    }
}
