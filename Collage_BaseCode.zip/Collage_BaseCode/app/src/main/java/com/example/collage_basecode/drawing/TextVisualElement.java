package com.example.collage_basecode.drawing;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;

public class TextVisualElement extends BaseVisualElement{

    private String text;
    private Typeface face;
    private float textSize;

    public TextVisualElement(float x, float y, String text, Typeface face, float textSize){
        paint.setTypeface(face);
        paint.setTextSize(textSize);
        this.x = x;
        this.y = y;
        this.text = text;
        this.face = face;
        this.textSize = textSize;
        //计算文本宽度
        this.w = paint.measureText(text);
        this.h = textSize;
    }

    @Override
    public void draw(Canvas onCanvas) {
        super.draw(onCanvas);
        //绘制文字时所用的坐标是文字的基线而非左上角
        Paint.FontMetrics metrics = paint.getFontMetrics();
        float bas = textSize / 2 + (metrics.descent - metrics.ascent) / 2 - metrics.descent;
        onCanvas.drawText(text,x,y+bas,paint);
        drawChilds(onCanvas);
    }


}
