package com.example.collage_basecode.drawing;

import android.graphics.Canvas;
import android.graphics.Paint;

public class SimpleFrame extends BaseVisualElement {

    //Paint paint;

    public SimpleFrame(float xLoc, float yLoc, float width, float height) {
        super(xLoc, yLoc, width, height);
        this.x = xLoc;
        this.y = yLoc;
        this.w = width;
        this.h = height;
    }

    @Override
    public void draw(Canvas onCanvas) {
        super.draw(onCanvas);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2f);
        onCanvas.drawRect(x,y,x+w,y+h,paint);
        drawChilds(onCanvas);
    }


}
