package com.example.collage_basecode.drawing;

import android.graphics.Canvas;
import android.graphics.Path;
import android.graphics.RectF;

public class OvalClip extends BaseVisualElement {

    public OvalClip(float xLoc, float yLoc, float width, float height) {
        super(xLoc, yLoc, width, height);
    }

    @Override
    protected void drawChilds(Canvas onCanvas) {
        onCanvas.save();
        onCanvas.translate(x,y);
        Path mPath = new Path();
        mPath.addOval(new RectF(0-1f,0-1f,w+1,h+1),Path.Direction.CW);
        onCanvas.clipPath(mPath);

        for (VisualElement child:
                childs) {
            child.draw(onCanvas);
        }
        onCanvas.translate(-x,-y);
        onCanvas.restore();
    }

    @Override
    public void draw(Canvas onCanvas) {
        super.draw(onCanvas);
        drawChilds(onCanvas);
    }

}
